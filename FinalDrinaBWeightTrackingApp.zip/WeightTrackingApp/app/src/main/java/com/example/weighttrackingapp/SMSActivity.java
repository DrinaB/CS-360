package com.example.weighttrackingapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    Button permissionButton, testNotificationButton;
    TextView permissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        permissionButton = findViewById(R.id.requestSmsPermissionButton);
        testNotificationButton = findViewById(R.id.testNotificationButton);
        permissionStatus = findViewById(R.id.smsPermissionStatus);

        updatePermissionUI();

        permissionButton.setOnClickListener(v -> requestSmsPermission());

        testNotificationButton.setOnClickListener(v -> {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("5554", null, "🎉 You reached your goal weight!", null, null);
                Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        Button backButton = new Button(this);
        backButton.setText("Back to History");

        // Style the button with margin
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        backParams.setMargins(0, 24, 0, 0);
        backButton.setLayoutParams(backParams);

        // Click listener to go back
        backButton.setOnClickListener(v -> {
            finish();
        });

        // Add the button to the screen layout
        LinearLayout layout = findViewById(R.id.smsLayout);
        layout.addView(backButton);
    }

    private void updatePermissionUI() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        permissionStatus.setText(granted ? "Permission granted" : "Permission not granted");
        testNotificationButton.setEnabled(granted);
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
            updatePermissionUI();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            updatePermissionUI();
        }
    }
}
