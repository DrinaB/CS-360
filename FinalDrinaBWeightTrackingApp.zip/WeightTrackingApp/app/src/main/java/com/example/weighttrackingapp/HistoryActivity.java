package com.example.weighttrackingapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class HistoryActivity extends AppCompatActivity {

    ListView weightListView;
    EditText inputWeight;
    Button addWeightButton;
    DataBaseHelper dbHelper;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Initialize views
        weightListView = findViewById(R.id.weightListView);
        inputWeight = findViewById(R.id.inputWeight);
        addWeightButton = findViewById(R.id.addWeightButton);
        dbHelper = new DataBaseHelper(this);

        // Set up adapter
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        weightListView.setAdapter(adapter);

        // Load existing weight entries
        loadWeights();

        // Handles "Add Weight" button click
        addWeightButton.setOnClickListener(v -> {
            String weightText = inputWeight.getText().toString();
            if (!weightText.isEmpty()) {
                double weight = Double.parseDouble(weightText);
                String date = java.time.LocalDate.now().toString();
                dbHelper.addWeight(weight, date);
                inputWeight.setText("");
                loadWeights();
            }
        });

        // Handles item click to delete entry
        weightListView.setOnItemClickListener((parent, view, position, id) -> {
            String selected = adapter.getItem(position);
            if (selected != null) {
                String[] parts = selected.split(" - ");
                int recordId = Integer.parseInt(parts[0]);
                dbHelper.deleteWeight(recordId);
                loadWeights();
            }
        });


        LinearLayout layout = findViewById(R.id.historyLayout);

        Button goToSMSButton = new Button(this);
        goToSMSButton.setText("Go to SMS Notifications");

        //  Adds margin to the button
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 16, 0, 0);
        goToSMSButton.setLayoutParams(params);

        // Button action: open SMSActivity
        goToSMSButton.setOnClickListener(v -> {
            startActivity(new Intent(this, SMSActivity.class));
        });

        // Adds the button to the bottom of the layout
        layout.addView(goToSMSButton);
    }

    private void loadWeights() {
        adapter.clear();
        Cursor cursor = dbHelper.getAllWeights();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            adapter.add(id + " - " + date + ": " + weight + " lbs");
        }
        cursor.close();
    }
}
